import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})
export class CalcComponent implements OnInit {
  valor1: number;
  valor2: number;
  operacion : string;
  constructor() {
    this.valor1 = 0;
    this.valor2 = 0;
    this.operacion = '';
  }
  setValor1(evento: Event) {
    this.valor1 = (evento.target as HTMLInputElement).valueAsNumber;
  }
  setValor2(evento: Event) {
    this.valor2 = (evento.target as HTMLInputElement).valueAsNumber;
  }
  setOperacion(evento: Event) {
    this.operacion = (evento.target as HTMLSelectElement).value;
  }
  ngOnInit(): void {
  }

}
