import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.css']
})
export class BodyComponent implements OnInit {
  title = 'clase-uno';
  public nombre:string;
  fechaDeNacimiento:Date;
  sueldo:number;
  color:string;
  otroColor:string;

  constructor() { 
    this.nombre = "Juan";
    this.fechaDeNacimiento= new Date();
    this.sueldo = 3000;
    this.color = "red";
    this.otroColor = "green";
  }
  cambiarNombre(){
    if(this.nombre === "Juan"){
      this.nombre="José";
    }else{
      this.nombre= "Juan"
    }
    
  }
  
  ngOnInit(): void {
  }
  
}
