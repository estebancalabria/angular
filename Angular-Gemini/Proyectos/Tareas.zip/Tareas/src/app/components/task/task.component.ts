import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-task',
  templateUrl: './task.component.html',
  styleUrls: ['./task.component.css']
})
export class TaskComponent implements OnInit {
  nuevoTask: string = "";
  task : any[] = [];
  list : any[]= [];
 /*  alumnos: string[] = []; */
  constructor() {
    /* this.alumnos=["Alejandro", "Fernando", "Aleksander", "Aimar", "Jano", "Cristina", "Joshua", "Federico", "Jose Maria"]; */
  }
  cambiarTask(evento: Event) {
    /* console.log(evento.constructor.name);
     console.log(evento); */
    this.nuevoTask = (evento.target as HTMLInputElement).value;
          }
  nuevaTask(item:string) {
      this.list.push({id:this.list.length,name:item});
      console.warn(this.list);

}
newTask(){
  
}
  borrarTask(id:number){
    this.list=this.list.filter(item=>item.id!==id);
  }
  ngOnInit(): void {
  }
}
