import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FooterComponent } from './components/footer/footer.component';
import { BodyComponent } from './components/body/body.component';
import { HeaderComponent } from './components/header/header.component';
import { CalcComponent } from './components/calc/calc.component';
import { TaskComponent } from './components/task/task.component';
import { NewtaskComponent } from './components/newtask/newtask.component';
const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: BodyComponent},
  { path: 'calc', component: CalcComponent},
  { path: 'task', component: TaskComponent},
  {path: 'newtask', component: NewtaskComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
